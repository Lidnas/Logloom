# Logloom

**Turn terminal chaos into a debugging report.**

Logloom is a local-first, cross-platform CLI that turns noisy build logs, test
failures and terminal output into a searchable, standalone HTML report. No
server, no account, no API key, no network calls.

```
2,000 lines in  ──▶  grouped findings + original line numbers + one HTML file
```

- **Local-first** — logs are processed on your machine and never uploaded.
- **No AI required** — deterministic analysis with transparent, inspectable heuristics.
- **Easy to share** — one self-contained HTML file that works offline.
- **Cross-platform** — tested on Windows and Linux, pure standard library.
- **Privacy-aware** — detects likely secrets and lets you review before sharing.

## Quick start

```bash
python -m pip install logloom

# analyse a file
logloom analyze build.log

# choose where the report goes
logloom analyze build.log --output report.html

# analyse output from another command
pytest 2>&1 | logloom analyze -

# machine-readable output
logloom analyze build.log --format json

# scrub likely secrets before sharing
logloom analyze build.log --redact --output share.html
```

No install? Clone and run it straight from the source tree:

```bash
git clone https://github.com/logloom/logloom
cd logloom
python -m logloom analyze examples/failed-tests.log
```

## How it works

1. **Parse** the original output line by line: ANSI colours stripped, timestamps
   and severity markers detected, stack frames identified, low-information
   progress lines marked as noise.
2. **Group** repeated messages by a normalised signature, so
   `connection refused to 10.0.0.7:5432 after 3 attempts` and
   `...10.0.0.9:5432 after 7 attempts` become a single finding with a count,
   the first occurrence, and every original line number.
3. **Label** a finding when it matches a curated pattern (`Missing module`,
   `Timeout`, `Permission denied`, `Out of memory`, …). Anything unrecognised is
   grouped but not labelled — Logloom never invents an explanation.
4. **Flag** likely secrets (AWS keys, GitHub tokens, PEM blocks, connection
   strings with passwords, …) and let you review them.
5. **Render** one standalone HTML file: search, severity filters, collapsible
   groups, stack frames, original line numbers, and the full raw output.

Logloom does **not** claim to find the root cause. It organises evidence so the
investigation is faster, and every finding points back at the original lines.

## What the report gives you

| Section | What it does |
| --- | --- |
| Stats | line counts, finding counts, duplicates folded, first error line |
| Findings | one card per signature: severity, label, count, first/last line, every occurrence, stack frames, file references |
| Potential secrets | every candidate with rule, confidence and preview, toggleable before export |
| Raw output | the complete original log, unmodified, with line numbers and severity markers |

## Command line options

```
logloom analyze [PATH] [OPTIONS]

  PATH                       log file, or '-' for stdin (default: stdin)
  -o, --output FILE          report file (default: logloom-report.html for html,
                             stdout for json)
  --format {html,json}       report format (default: html)
  --redact                   replace detected secrets in the report
  --no-raw                   omit the raw output section
  --title TEXT               report title
  --min-severity LEVEL       warning (default), info, debug or log
  --fail-on {never,warning,error}
                             exit non-zero when findings reach this severity
  --stdout                   write the report to stdout
  -q, --quiet                suppress the stderr summary
```

Streams are strict on purpose: **stdin** is only ever log input, **stdout** only
ever carries an explicitly requested report, and all diagnostics go to **stderr**.
That makes `make build 2>&1 | logloom analyze -` safe.

## Examples

```bash
# CI: fail the job when the log contains errors
logloom analyze build.log --fail-on error -o build-report.html

# a redacted copy safe to attach to a bug report
logloom analyze debug.log --redact -o share.html

# count findings without writing a file
logloom analyze debug.log --format json | python -c "import json,sys; print(json.load(sys.stdin)['summary'])"
```

Sample logs live in [`examples/`](examples) and [`tests/fixtures/`](tests/fixtures).

## Limitations

- Findings are grouped by message signature. Logloom does not infer causality.
- Labels come from a curated pattern list; unknown failures are grouped with a
  truncated message as the title instead of a guess.
- Secret detection is pattern based. It catches common credential shapes, not
  every encoding. Review the report before sharing it.
- Without `--redact`, the report *file itself* contains the original text —
  including any secrets it highlights. The toolbar toggle only affects the
  view in your browser.

## Requirements

Python 3.9 or newer. No runtime dependencies.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Real-world log fixtures are the most
useful contribution — see [docs/design.md](docs/design.md) for the heuristics.

## Status

Early development (v0.1.0). Bug reports, heuristics improvements and
sanitised real-world log samples are welcome.

## License

MIT — see [LICENSE](LICENSE).